<?php

namespace Pusher\Actions;

class ThemeWasUnlinked
{
}
